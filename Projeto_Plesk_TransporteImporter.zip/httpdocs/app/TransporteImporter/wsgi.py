#!/usr/bin/env python3
"""
WSGI Configuration for Cyberpanel/cPanel hosting
"""
import sys
import os

# Add the application directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the Flask application
from app import app
import routes
import api_routes

# Set production environment variables
os.environ.setdefault('FLASK_ENV', 'production')

# Configure for production
app.config['DEBUG'] = False

# This is what the WSGI server will call
application = app

if __name__ == "__main__":
    # For development testing
    app.run(host='0.0.0.0', port=5000)