#!/usr/bin/env python3
"""
Setup script for web hosting deployment
Run this after uploading files to create database tables
"""
import os
import sys

def setup_database():
    """Initialize database for hosting environment"""
    try:
        # Set environment for production
        os.environ['FLASK_ENV'] = 'production'
        os.environ['INIT_DB'] = 'true'
        
        # Import and initialize
        from app import app, db
        import models
        
        with app.app_context():
            print("Creating database tables...")
            db.create_all()
            print("Database setup completed successfully!")
            
            # Test database connection
            from models import Cliente
            test_count = Cliente.query.count()
            print(f"Database connection test: {test_count} clients found")
            
    except Exception as e:
        print(f"Error setting up database: {e}")
        sys.exit(1)

def create_env_template():
    """Create environment variables template file"""
    env_content = """# Environment Variables for Web Hosting
# Copy this file to .env and fill in your values

# Database Configuration (MySQL)
DB_HOST=localhost
DB_NAME=your_database_name
DB_USER=your_database_user
DB_PASSWORD=your_database_password

# Or use full DATABASE_URL
# DATABASE_URL=mysql+pymysql://user:password@localhost/database_name

# Security
SESSION_SECRET=your-random-secret-key-change-this

# Application Settings
FLASK_ENV=production
"""
    
    with open('.env.template', 'w') as f:
        f.write(env_content)
    print("Created .env.template file")

def check_requirements():
    """Check if all required packages are available"""
    required_packages = [
        'flask', 'flask_sqlalchemy', 'werkzeug', 
        'sqlalchemy', 'pymysql'
    ]
    
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✓ {package}")
        except ImportError:
            missing_packages.append(package)
            print(f"✗ {package} - MISSING")
    
    if missing_packages:
        print(f"\nInstall missing packages:")
        print(f"pip install {' '.join(missing_packages)}")
        return False
    
    print("\nAll required packages are available!")
    return True

if __name__ == "__main__":
    print("=== Web Hosting Setup Script ===\n")
    
    # Check requirements
    if not check_requirements():
        sys.exit(1)
    
    # Create environment template
    create_env_template()
    
    # Setup database
    setup_database()
    
    print("\n=== Setup Complete ===")
    print("Next steps:")
    print("1. Configure your database settings in .env")
    print("2. Upload all files to your web hosting")
    print("3. Access your domain to test the application")
    print("4. Use /discord for Discord bot interface")