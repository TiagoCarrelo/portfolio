# Deployment Guide - Cyberpanel/cPanel Web Hosting

## Overview
This guide covers deploying the Transportation Management System to Cyberpanel or any cPanel-based web hosting service.

## Files Structure for Upload
```
your_domain/
├── public_html/
│   ├── app.py                 # Main Flask application
│   ├── wsgi.py               # WSGI configuration
│   ├── passenger_wsgi.py     # Passenger WSGI (main entry point)
│   ├── main.py               # Alternative entry point
│   ├── config.py             # Configuration management
│   ├── routes.py             # Web routes
│   ├── api_routes.py         # API endpoints
│   ├── models.py             # Database models
│   ├── requirements.txt      # Python dependencies
│   ├── setup_hosting.py      # Setup script
│   ├── .htaccess            # Apache configuration
│   ├── templates/           # HTML templates
│   │   ├── base.html
│   │   ├── agenda.html
│   │   ├── importar.html
│   │   ├── preview.html
│   │   ├── mensagem_whatsapp.html
│   │   └── discord_interface.html
│   └── static/              # CSS/JS files
│       └── style.css
```

## Step 1: Prepare Database

### Option A: MySQL Database (Recommended)
1. **Create MySQL Database in cPanel:**
   - Go to cPanel → MySQL Databases
   - Create database: `transportes_db`
   - Create user: `transportes_user`
   - Add user to database with ALL PRIVILEGES

2. **Note your database credentials:**
   ```
   Host: localhost
   Database: yourusername_transportes_db
   Username: yourusername_transportes_user
   Password: your_password
   ```

### Option B: SQLite (Basic hosting)
- Uses local file storage
- No additional setup required
- Limited concurrent users

## Step 2: Configure Environment

1. **Create .env file** in your public_html directory:
```bash
# Database Configuration
DB_HOST=localhost
DB_NAME=yourusername_transportes_db
DB_USER=yourusername_transportes_user
DB_PASSWORD=your_database_password

# Security Key (generate random string)
SESSION_SECRET=your-super-secret-random-key-here

# Environment
FLASK_ENV=production
```

2. **Update .htaccess** with your username:
```apache
# Replace 'yourusername' with your actual hosting username
SetEnv PYTHONPATH /home/yourusername/public_html
```

## Step 3: Install Python Dependencies

### Option A: Using pip (if available)
```bash
cd public_html
pip install -r requirements.txt --user
```

### Option B: Using cPanel Python App
1. Go to cPanel → Setup Python App
2. Create new Python application
3. Set application root to `public_html`
4. Install packages from requirements.txt

### Option C: Contact hosting support
If you can't install packages, contact your hosting provider to install:
- Flask
- Flask-SQLAlchemy
- PyMySQL
- SQLAlchemy

## Step 4: Initialize Database

Run the setup script:
```bash
cd public_html
python setup_hosting.py
```

Or manually:
```bash
cd public_html
python -c "
import os
os.environ['FLASK_ENV'] = 'production'
os.environ['INIT_DB'] = 'true'
from app import app, db
import models
with app.app_context():
    db.create_all()
    print('Database initialized!')
"
```

## Step 5: Configure Web Server

### For Passenger (most shared hosting)
- File `passenger_wsgi.py` is the main entry point
- No additional configuration needed

### For Apache with mod_wsgi
- Use `wsgi.py` as the WSGI file
- Configure virtual host if needed

## Step 6: Test Installation

1. **Access your domain:** `https://yourdomain.com`
2. **Test Discord interface:** `https://yourdomain.com/discord`
3. **Test API:** `https://yourdomain.com/api/estatisticas`

## Step 7: Configure Discord Bot (Optional)

Update `discord_bot_example.py`:
```python
# Change this line:
API_BASE_URL = 'https://yourdomain.com'  # Your actual domain
```

## Common Hosting Providers Configuration

### Cyberpanel
- Uses LiteSpeed web server
- Passenger WSGI support built-in
- Python path: `/usr/bin/python3`

### cPanel with CloudLinux
- Uses Apache with Passenger
- May need to request Python app setup
- Check Python version availability

### Shared Hosting (General)
- Usually supports Python 3.7+
- SQLite fallback if MySQL unavailable
- File permissions may need adjustment

## Troubleshooting

### 500 Internal Server Error
1. Check error logs in cPanel
2. Verify Python path in `.htaccess`
3. Ensure all files have correct permissions (644 for files, 755 for directories)

### Database Connection Error
1. Verify database credentials
2. Check if database user has proper privileges
3. Test connection from hosting control panel

### Import Errors
1. Check if all required packages are installed
2. Verify Python version compatibility
3. Contact hosting support for package installation

### Permission Denied
```bash
# Fix file permissions
find public_html -type f -exec chmod 644 {} \;
find public_html -type d -exec chmod 755 {} \;
chmod 755 public_html/passenger_wsgi.py
```

## Performance Optimization

### Enable Caching
Add to `.htaccess`:
```apache
# Enable compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/plain
    AddOutputFilterByType DEFLATE text/html
    AddOutputFilterByType DEFLATE text/xml
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/xml
    AddOutputFilterByType DEFLATE application/xhtml+xml
    AddOutputFilterByType DEFLATE application/rss+xml
    AddOutputFilterByType DEFLATE application/javascript
    AddOutputFilterByType DEFLATE application/x-javascript
</IfModule>
```

### Database Optimization
- Use connection pooling (already configured)
- Consider upgrading to dedicated MySQL if needed
- Monitor query performance

## Security Considerations

1. **Change default secret key**
2. **Use strong database passwords**
3. **Keep dependencies updated**
4. **Enable HTTPS if available**
5. **Restrict file access via .htaccess**

## Support

### Check Logs
- cPanel → Error Logs
- Application logs in your hosting account

### Common Issues
- Python version compatibility
- Package installation permissions
- Database connection limits
- File upload size limits

### Resources
- Hosting provider documentation
- Python/Flask hosting guides
- Community forums for your hosting provider

## API Endpoints Available

After deployment, these endpoints will be available:

- `GET /` - Main interface
- `GET /discord` - Discord-themed interface
- `POST /api/processar_mensagem` - Process client messages
- `GET /api/estatisticas` - Get statistics
- `GET /api/gerar_mensagem_whatsapp/<regiao>` - Generate WhatsApp messages
- `POST /api/limpar_lista` - Clear client list
- `GET /api/regioes` - List regions

Your system is now ready for production use on web hosting!