# Integração Discord Bot - Sistema de Transportes

## Visão Geral
O sistema de transportes agora inclui uma interface Discord completamente funcional com APIs REST e uma interface web otimizada para Discord bots.

## Funcionalidades Implementadas

### 📱 Interface Discord Web
- **URL**: `/discord`
- Design adaptado ao tema Discord (cores escuras, tipografia Whitney)
- Interface responsiva e interativa
- Estatísticas em tempo real
- Gestão completa de clientes e regiões

### 🔌 APIs REST

#### 1. Processar Mensagem
```
POST /api/processar_mensagem
Content-Type: application/json

{
  "mensagem": "Cliente 1 16:00 Hospital Seguro Morada 912345678, Cliente 2..."
}
```

**Resposta:**
```json
{
  "success": true,
  "clientes_importados": 2,
  "regioes_detectadas": ["Lisboa", "Sintra"],
  "detalhes": [...]
}
```

#### 2. Estatísticas
```
GET /api/estatisticas
```

**Resposta:**
```json
{
  "success": true,
  "total_clientes": 10,
  "total_agendamentos": 8,
  "status": {
    "importados": 5,
    "transportados": 3,
    "removidos": 2
  },
  "por_regiao": {
    "Lisboa": 6,
    "Sintra": 4
  }
}
```

#### 3. Gerar Mensagem WhatsApp
```
GET /api/gerar_mensagem_whatsapp/<regiao>
```

**Resposta:**
```json
{
  "success": true,
  "regiao": "Lisboa",
  "total_clientes": 5,
  "mensagem": "📋 *Lista de Clientes - Motorista Lisboa*\n...",
  "clientes": [...]
}
```

#### 4. Listar Regiões
```
GET /api/regioes
```

#### 5. Limpar Lista
```
POST /api/limpar_lista
```

#### 6. Finalizar Agendamento
```
POST /api/finalizar_agendamento/<agendamento_id>
```

## 🤖 Bot Discord de Exemplo

O arquivo `discord_bot_example.py` contém um bot Discord completo com os seguintes comandos:

### Comandos Disponíveis

#### `!importar <mensagem>`
Importa uma lista de clientes do formato da seguradora.
```
!importar Tiago Joaquim 16:00 Hospital Seguro Morada 912345678, João Silva...
```

#### `!stats`
Mostra estatísticas completas do sistema.

#### `!whatsapp <regiao>`
Gera e envia mensagem WhatsApp formatada para uma região específica.
```
!whatsapp Lisboa
```

#### `!limpar`
Limpa toda a lista de clientes (com confirmação).

#### `!web`
Fornece links para as interfaces web disponíveis.

## 🚀 Como Implementar

### 1. Para usar as APIs diretamente:
```python
import requests

# Processar mensagem
response = requests.post('http://seu-dominio.com/api/processar_mensagem', 
                        json={'mensagem': 'sua_mensagem'})
data = response.json()
```

### 2. Para Discord Bot:
```bash
# Instalar dependências
pip install discord.py aiohttp

# Configurar o bot
python discord_bot_example.py
```

### 3. Para interface web:
Acesse `/discord` para a interface otimizada para Discord.

## 🎨 Características da Interface Discord

### Design
- Tema escuro consistente com Discord
- Cores da paleta Discord (#5865f2, #36393f, etc.)
- Tipografia Whitney (fonte oficial do Discord)
- Cards com bordas arredondadas

### Funcionalidades
- Importação de mensagens com preview
- Geração automática de mensagens WhatsApp
- Estatísticas em tempo real
- Gestão de regiões
- Limpeza de dados com confirmação

### Interatividade
- Botões responsivos
- Atualizações automáticas
- Cópia automática para clipboard
- Integração com WhatsApp Web

## 📋 Fluxo de Trabalho Típico

1. **Importar Clientes**: Cole a mensagem da seguradora
2. **Verificar Estatísticas**: Veja quantos clientes foram processados
3. **Gerar WhatsApp**: Crie mensagens para cada motorista por região
4. **Enviar**: Copie e envie as mensagens
5. **Limpar**: Prepare para a próxima lista

## 🔧 Configuração

### Para Bot Discord:
1. Crie uma aplicação no Discord Developer Portal
2. Obtenha o token do bot
3. Configure as permissões necessárias
4. Substitua `SEU_TOKEN_DO_DISCORD` no código

### Para Deploy:
1. Configure a URL base no `discord_bot_example.py`
2. Certifique-se que a aplicação Flask está acessível
3. Configure CORS se necessário para APIs externas

## 🛡️ Segurança

- Todas as APIs incluem tratamento de erros
- Validação de dados de entrada
- Proteção contra SQL injection através do SQLAlchemy
- Confirmações para operações destrutivas

## 📞 Suporte

O sistema mantém total compatibilidade com a interface web original em `/agenda` enquanto adiciona estas novas funcionalidades específicas para Discord.