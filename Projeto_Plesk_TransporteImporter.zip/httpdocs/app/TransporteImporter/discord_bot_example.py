"""
Exemplo de como integrar com Discord Bot
Este arquivo mostra como usar as APIs criadas num bot Discord
"""

import discord
from discord.ext import commands
import aiohttp
import asyncio

# Configuração do bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix='!', intents=intents)

# URL da sua aplicação Flask
API_BASE_URL = 'http://localhost:5000'  # Altere para o seu domínio

class TransportesBot:
    def __init__(self, bot):
        self.bot = bot
        self.session = None
    
    async def setup(self):
        """Configurar sessão HTTP"""
        self.session = aiohttp.ClientSession()
    
    async def cleanup(self):
        """Limpar recursos"""
        if self.session:
            await self.session.close()

# Instanciar o sistema de transportes
transportes = TransportesBot(bot)

@bot.event
async def on_ready():
    """Evento quando o bot fica online"""
    await transportes.setup()
    print(f'{bot.user} está online e conectado ao sistema de transportes!')

@bot.command(name='importar')
async def importar_clientes(ctx, *, mensagem):
    """
    Comando para importar clientes
    Uso: !importar Tiago Joaquim 16:00 Hospital Seguro Morada 912345678, João...
    """
    try:
        async with transportes.session.post(
            f'{API_BASE_URL}/api/processar_mensagem',
            json={'mensagem': mensagem}
        ) as response:
            data = await response.json()
            
            if data.get('success'):
                embed = discord.Embed(
                    title="✅ Clientes Importados",
                    color=discord.Color.green(),
                    description=f"Processados **{data['clientes_importados']}** clientes"
                )
                embed.add_field(
                    name="Regiões Detectadas",
                    value=", ".join(data['regioes_detectadas']),
                    inline=False
                )
                
                # Adicionar detalhes dos clientes
                if data.get('detalhes'):
                    detalhes = []
                    for cliente in data['detalhes'][:5]:  # Mostrar apenas os primeiros 5
                        detalhes.append(f"• {cliente['nome']} - {cliente['regiao']}")
                    
                    embed.add_field(
                        name="Clientes Importados",
                        value="\n".join(detalhes),
                        inline=False
                    )
                
                await ctx.send(embed=embed)
            else:
                await ctx.send(f"❌ Erro ao importar: {data.get('error')}")
    
    except Exception as e:
        await ctx.send(f"❌ Erro na conexão: {str(e)}")

@bot.command(name='stats')
async def estatisticas(ctx):
    """
    Comando para ver estatísticas
    Uso: !stats
    """
    try:
        async with transportes.session.get(f'{API_BASE_URL}/api/estatisticas') as response:
            data = await response.json()
            
            if data.get('success'):
                embed = discord.Embed(
                    title="📊 Estatísticas do Sistema",
                    color=discord.Color.blue()
                )
                
                embed.add_field(
                    name="Total de Clientes",
                    value=str(data['total_clientes']),
                    inline=True
                )
                embed.add_field(
                    name="Transportados",
                    value=str(data['status']['transportados']),
                    inline=True
                )
                embed.add_field(
                    name="Pendentes",
                    value=str(data['status']['importados']),
                    inline=True
                )
                
                # Regiões
                if data['por_regiao']:
                    regioes_info = []
                    for regiao, count in data['por_regiao'].items():
                        regioes_info.append(f"• {regiao}: {count} clientes")
                    
                    embed.add_field(
                        name="Por Região",
                        value="\n".join(regioes_info),
                        inline=False
                    )
                
                await ctx.send(embed=embed)
            else:
                await ctx.send(f"❌ Erro: {data.get('error')}")
    
    except Exception as e:
        await ctx.send(f"❌ Erro na conexão: {str(e)}")

@bot.command(name='whatsapp')
async def gerar_whatsapp(ctx, regiao):
    """
    Comando para gerar mensagem WhatsApp
    Uso: !whatsapp Lisboa
    """
    try:
        async with transportes.session.get(
            f'{API_BASE_URL}/api/gerar_mensagem_whatsapp/{regiao}'
        ) as response:
            data = await response.json()
            
            if data.get('success'):
                # Criar arquivo com a mensagem
                mensagem_file = discord.File(
                    fp=aiohttp.BytesIO(data['mensagem'].encode('utf-8')),
                    filename=f'clientes_{regiao}.txt'
                )
                
                embed = discord.Embed(
                    title=f"📱 Mensagem WhatsApp - {regiao}",
                    color=discord.Color.green(),
                    description=f"Mensagem gerada para **{data['total_clientes']}** clientes"
                )
                
                embed.add_field(
                    name="Instruções",
                    value="1. Descarregue o arquivo anexo\n2. Copie o conteúdo\n3. Cole no WhatsApp do motorista",
                    inline=False
                )
                
                await ctx.send(embed=embed, file=mensagem_file)
            else:
                await ctx.send(f"❌ Erro: {data.get('error')}")
    
    except Exception as e:
        await ctx.send(f"❌ Erro na conexão: {str(e)}")

@bot.command(name='limpar')
async def limpar_lista(ctx):
    """
    Comando para limpar lista de clientes
    Uso: !limpar
    """
    # Pedir confirmação
    embed = discord.Embed(
        title="⚠️ Confirmação Necessária",
        description="Tem certeza que quer limpar toda a lista de clientes?",
        color=discord.Color.orange()
    )
    embed.add_field(
        name="Para confirmar",
        value="Reaja com ✅ em 30 segundos",
        inline=False
    )
    
    msg = await ctx.send(embed=embed)
    await msg.add_reaction('✅')
    await msg.add_reaction('❌')
    
    def check(reaction, user):
        return user == ctx.author and str(reaction.emoji) in ['✅', '❌'] and reaction.message.id == msg.id
    
    try:
        reaction, user = await bot.wait_for('reaction_add', timeout=30.0, check=check)
        
        if str(reaction.emoji) == '✅':
            async with transportes.session.post(f'{API_BASE_URL}/api/limpar_lista') as response:
                data = await response.json()
                
                if data.get('success'):
                    embed = discord.Embed(
                        title="🗑️ Lista Limpa",
                        color=discord.Color.green(),
                        description=f"Removidos {data['removidos']['clientes']} clientes"
                    )
                    await ctx.send(embed=embed)
                else:
                    await ctx.send(f"❌ Erro: {data.get('error')}")
        else:
            await ctx.send("❌ Operação cancelada")
    
    except asyncio.TimeoutError:
        await ctx.send("⏰ Tempo esgotado. Operação cancelada.")
    except Exception as e:
        await ctx.send(f"❌ Erro: {str(e)}")

@bot.command(name='web')
async def interface_web(ctx):
    """
    Comando para obter link da interface web
    Uso: !web
    """
    embed = discord.Embed(
        title="🌐 Interface Web",
        description="Acesse a interface web completa do sistema",
        color=discord.Color.purple()
    )
    embed.add_field(
        name="Link da Interface Discord",
        value=f"{API_BASE_URL}/discord",
        inline=False
    )
    embed.add_field(
        name="Link da Interface Principal",
        value=f"{API_BASE_URL}/agenda",
        inline=False
    )
    
    await ctx.send(embed=embed)

@bot.event
async def on_command_error(ctx, error):
    """Tratamento de erros"""
    if isinstance(error, commands.CommandNotFound):
        return
    
    embed = discord.Embed(
        title="❌ Erro",
        description=str(error),
        color=discord.Color.red()
    )
    await ctx.send(embed=embed)

# Para executar o bot (substitua pelo seu token)
# bot.run('SEU_TOKEN_DO_DISCORD')

if __name__ == "__main__":
    print("Este é um exemplo de bot Discord para o sistema de transportes.")
    print("Para usar:")
    print("1. Instale discord.py: pip install discord.py")
    print("2. Crie um bot no Discord Developer Portal")
    print("3. Substitua 'SEU_TOKEN_DO_DISCORD' pelo token real")
    print("4. Execute: python discord_bot_example.py")
    print("5. Use os comandos: !importar, !stats, !whatsapp, !limpar, !web")