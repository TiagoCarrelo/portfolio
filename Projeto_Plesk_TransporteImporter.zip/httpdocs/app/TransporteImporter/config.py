"""
Configuration for different hosting environments
"""
import os

class Config:
    """Base configuration"""
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-secret-key-change-this')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', 'sqlite:///transportes.db')

class ProductionConfig(Config):
    """Production configuration for web hosting"""
    DEBUG = False
    
    # Database configuration priority:
    # 1. Full DATABASE_URL if provided
    # 2. Individual MySQL components
    # 3. SQLite fallback
    
    database_url = os.environ.get('DATABASE_URL')
    
    if not database_url:
        # MySQL configuration for shared hosting
        db_host = os.environ.get('DB_HOST', 'localhost')
        db_name = os.environ.get('DB_NAME', 'transportes_db')
        db_user = os.environ.get('DB_USER', 'root')
        db_pass = os.environ.get('DB_PASSWORD', '')
        
        if db_name and db_user:
            database_url = f"mysql+pymysql://{db_user}:{db_pass}@{db_host}/{db_name}"
        else:
            # SQLite fallback for basic hosting
            database_url = 'sqlite:///transportes.db'
    
    SQLALCHEMY_DATABASE_URI = database_url

class CyberpanelConfig(ProductionConfig):
    """Specific configuration for Cyberpanel hosting"""
    # Cyberpanel typically uses these paths
    UPLOAD_FOLDER = '/home/username/public_html/uploads'
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

# Configuration mapping
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'cyberpanel': CyberpanelConfig,
    'default': DevelopmentConfig
}