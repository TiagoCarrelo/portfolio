from app import app
import routes
import api_routes

if __name__ == "__main__":
    app.run(debug=True)
