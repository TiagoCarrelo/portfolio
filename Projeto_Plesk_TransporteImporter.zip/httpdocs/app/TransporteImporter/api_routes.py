from app import app, db
from models import Cliente, Agendamento
from flask import jsonify, request, render_template
from routes import processar_mensagem_seguro, detectar_regiao_geografica
from datetime import datetime
import re

# API Routes para Discord Bot
@app.route('/api/processar_mensagem', methods=['POST'])
def api_processar_mensagem():
    """API endpoint para processar mensagem de clientes"""
    try:
        data = request.get_json()
        mensagem = data.get('mensagem', '')
        
        if not mensagem:
            return jsonify({'error': 'Mensagem não fornecida'}), 400
        
        resultado = processar_mensagem_seguro(mensagem)
        
        return jsonify({
            'success': True,
            'clientes_importados': len(resultado['clientes_importados']),
            'regioes_detectadas': resultado['regioes_detectadas'],
            'detalhes': [
                {
                    'nome': cliente.nome,
                    'regiao': cliente.regiao,
                    'destino': cliente.destino,
                    'horario': cliente.horario,
                    'contacto': cliente.contacto
                } for cliente in resultado['clientes_importados']
            ]
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/gerar_mensagem_whatsapp/<regiao>')
def api_gerar_mensagem_whatsapp(regiao):
    """API endpoint para gerar mensagem WhatsApp para uma região"""
    try:
        clientes = Cliente.query.filter_by(regiao=regiao).all()
        
        if not clientes:
            return jsonify({'error': f'Nenhum cliente encontrado na região {regiao}'}), 404
        
        # Gerar mensagem formatada
        mensagem_lines = []
        mensagem_lines.append(f"📋 *Lista de Clientes - Motorista {regiao}*")
        mensagem_lines.append(f"📅 Data: {datetime.now().strftime('%d/%m/%Y')}")
        mensagem_lines.append("")
        
        for i, cliente in enumerate(clientes, 1):
            mensagem_lines.append(f"*{i}. {cliente.nome}*")
            mensagem_lines.append(f"🏠 Morada: {cliente.morada}")
            mensagem_lines.append(f"🏥 Destino: {cliente.destino}")
            mensagem_lines.append(f"⏰ Horário: {cliente.horario}")
            mensagem_lines.append(f"📞 Contacto: {cliente.contacto}")
            mensagem_lines.append("")
        
        mensagem_lines.append(f"Total: {len(clientes)} clientes")
        
        return jsonify({
            'success': True,
            'regiao': regiao,
            'total_clientes': len(clientes),
            'mensagem': "\n".join(mensagem_lines),
            'clientes': [
                {
                    'nome': cliente.nome,
                    'morada': cliente.morada,
                    'destino': cliente.destino,
                    'horario': cliente.horario,
                    'contacto': cliente.contacto
                } for cliente in clientes
            ]
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/estatisticas')
def api_estatisticas():
    """API endpoint para obter estatísticas dos clientes"""
    try:
        total_clientes = Cliente.query.count()
        total_agendamentos = Agendamento.query.count()
        
        # Por status
        importados = Cliente.query.filter_by(status_cliente='Importado').count()
        transportados = Cliente.query.filter_by(status_cliente='Transportado').count()
        removidos = Cliente.query.filter_by(status_cliente='Removido').count()
        
        # Por região
        from collections import defaultdict
        clientes_por_regiao = defaultdict(int)
        for cliente in Cliente.query.all():
            clientes_por_regiao[cliente.regiao] += 1
        
        return jsonify({
            'success': True,
            'total_clientes': total_clientes,
            'total_agendamentos': total_agendamentos,
            'status': {
                'importados': importados,
                'transportados': transportados,
                'removidos': removidos
            },
            'por_regiao': dict(clientes_por_regiao)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/limpar_lista', methods=['POST'])
def api_limpar_lista():
    """API endpoint para limpar lista de clientes"""
    try:
        num_clientes = Cliente.query.count()
        num_agendamentos = Agendamento.query.count()
        
        # Apagar agendamentos primeiro
        Agendamento.query.delete()
        Cliente.query.delete()
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'removidos': {
                'clientes': num_clientes,
                'agendamentos': num_agendamentos
            }
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/regioes')
def api_regioes():
    """API endpoint para listar todas as regiões com clientes"""
    try:
        from collections import defaultdict
        regioes_info = defaultdict(lambda: {'clientes': 0, 'lista': []})
        
        for cliente in Cliente.query.all():
            regioes_info[cliente.regiao]['clientes'] += 1
            regioes_info[cliente.regiao]['lista'].append({
                'nome': cliente.nome,
                'destino': cliente.destino,
                'horario': cliente.horario,
                'contacto': cliente.contacto,
                'status': cliente.status_cliente
            })
        
        return jsonify({
            'success': True,
            'regioes': dict(regioes_info)
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/finalizar_agendamento/<int:agendamento_id>', methods=['POST'])
def api_finalizar_agendamento(agendamento_id):
    """API endpoint para finalizar um agendamento"""
    try:
        agendamento = Agendamento.query.get_or_404(agendamento_id)
        agendamento.status = 'Concluído'
        agendamento.cliente.status_cliente = 'Transportado'
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'agendamento_id': agendamento_id,
            'cliente_nome': agendamento.cliente.nome,
            'status': 'Transportado'
        })
    
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/discord')
def discord_interface():
    """Interface simplificada para Discord bot"""
    return render_template('discord_interface.html')