#!/usr/bin/env python3
"""
Passenger WSGI Configuration for shared hosting
Used by Cyberpanel and most cPanel hosts
"""
import sys, os

# Add current directory to Python path
INTERP = "/usr/bin/python3"
if sys.executable != INTERP:
    os.execl(INTERP, INTERP, *sys.argv)

# Add application directory to path
sys.path.insert(0, os.getcwd())

# Import Flask application
from app import app
import routes
import api_routes

# Configure for production
app.config['DEBUG'] = False

# Passenger requires 'application' variable
application = app